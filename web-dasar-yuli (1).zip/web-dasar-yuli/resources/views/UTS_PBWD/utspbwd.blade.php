<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Produk</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>UJIAN TENGAH SEMESTER PBWD</h1>
    <h2>Tabel Produk Somethinc</h2>

    <table border="1">
        <thead class="thead">
            <tr>
                <th>No</th>
                <th>Nama Produk</th>
                <th>Shade</th>
                <th>Harga</th>
            </tr>
        </thead>

        <tbody class="tbody">
            <tr>
                <td>01</td>
                <td>Somethinc Checkmatte Transferproof Lipstick</td>
                <td>01 Bishop</td>
                <td>Rp. 107.000</td>
            </tr>
            <tr>
                <td>02</td>
                <td>Copy Paste Tinted Sunscreen SPF 40PA++++</td>
                <td>W01 Bijoux</td>
                <td>Rp. 158.500</td>
            </tr>
            <tr>
                <td>03</td>
                <td>Hooman Breathable UV Cushion Cover SPF 35 PA++++</td>
                <td>NO2.5 Linen</td>
                <td>Rp. 141.500</td>
            </tr>
        </tbody>
    </table>
</body>
</html>